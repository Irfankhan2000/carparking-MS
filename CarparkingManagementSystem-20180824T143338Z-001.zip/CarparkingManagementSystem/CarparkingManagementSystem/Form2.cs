﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        Form1 conn = new Form1();

        public Form2()
        {
            
            InitializeComponent();
         
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.panel1.Visible = true;
            this.panel2.Visible = false;
            this.panel3.Visible = false;
         
        }
      
        private void Form2_Load(object sender, EventArgs e)
        {
            this.panel3.Visible = false;
            this.panel1.Visible = false;
            this.WindowState = FormWindowState.Maximized;
            this.panel2.Visible = false;
            conn.oleDbConnection1.Open();
            OleDbCommand icmd = new OleDbCommand("select Regno from registration ", conn.oleDbConnection1);
            OleDbDataReader idr = icmd.ExecuteReader();
            while (idr.Read())
            {
                this.comboBox1.Items.Add(idr["Regno"].ToString());

            }
            conn.oleDbConnection1.Close();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("insert into Registration(Regno,Phno,Payment,Namee,RegDate,Floor,Status) values (@Regno,@Phno,@Payment,@Namee,@RegDate,@Floor,@Status);", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@Regno", this.textBox5.Text);
            cmd.Parameters.AddWithValue("@Phno", this.textBox3.Text).ToString();
            cmd.Parameters.AddWithValue("@Payment", this.textBox7.Text).ToString();
            cmd.Parameters.AddWithValue("@Namee,", this.textBox1.Text);
            cmd.Parameters.AddWithValue("@RegDate", this.dateTimePicker1);
            cmd.Parameters.AddWithValue("@Floor", this.textBox8.Text).ToString();
            cmd.Parameters.AddWithValue("@Status","Unpaid");
            cmd.ExecuteNonQuery();
            conn.oleDbConnection1.Close();
            MessageBox.Show("Data inserted");
           

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            int a=0;
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select count(Regno) from Registration ", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                a = Convert.ToInt32(dr[0]); a++;
                textBox5.Text = "Reg_00" + a.ToString() + "--" + System.DateTime.Today.Year;
            }
            conn.oleDbConnection1.Close();
        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.panel2.Visible = true;

            this.panel1.Visible = false;
            this.panel3.Visible = false;
           
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.panel3.Visible = true;
            this.panel2.Visible = false;
            this.panel1.Visible = false;



        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("update Registration set Regno=@Regno,Phno=@Phno,Payment=@Payment,Namee=@Namee,RegDate=@RegDate,Floor=@Floor where Regno='" +textBox5.Text +"'", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@Regno", this.textBox5.Text);
            cmd.Parameters.AddWithValue("@Phno", this.textBox3.Text).ToString();
            cmd.Parameters.AddWithValue("@Payment", this.textBox7.Text).ToString();
            cmd.Parameters.AddWithValue("@Namee,", this.textBox1.Text);
            cmd.Parameters.AddWithValue("@RegDate", this.dateTimePicker1);
            cmd.Parameters.AddWithValue("@Floor", this.textBox8.Text).ToString();
            cmd.ExecuteNonQuery();
            conn.oleDbConnection1.Close();
            MessageBox.Show("Data updated");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select Namee,Floor,Phno,Payment from Registration where Regno='" + comboBox1.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox10.Text = dr["Namee"].ToString();
                textBox11.Text = dr["Floor"].ToString();
                textBox4.Text = dr["Phno"].ToString();
                textBox12.Text = dr["Payment"].ToString();
               }
            conn.oleDbConnection1.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("insert into Paymententry(Regno,Namee,MOPay,Phno,Fees,Floor,Status) values (@Regno,@Namee,@MOPay,@Phno,@Fees,@Floor,@Status);", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@Regno",this.comboBox1.Text );
            cmd.Parameters.AddWithValue("@Namee", this.textBox10.Text);
            cmd.Parameters.AddWithValue("@MOPay", this.textBox9.Text);
            cmd.Parameters.AddWithValue("@Phno,", this.textBox4.Text);
            cmd.Parameters.AddWithValue("@Fees", this.textBox12.Text);
            cmd.Parameters.AddWithValue("@Floor", this.textBox11.Text);
            cmd.Parameters.AddWithValue("@Status", "Paid");
            cmd.ExecuteNonQuery();
            conn.oleDbConnection1.Close();
            MessageBox.Show("Data inserted");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from Paymententry where Regno =@Regno", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@Regno", comboBox1.Text);
            OleDbDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            conn.oleDbConnection1.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("update Paymententry set Regno=@Regno,Namee=@Namee,MOPay=@MOPay,Phno=@Phno,Fees=@Fees,Floor=@Floor,Status=@Status", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@Regno", this.comboBox1.Text);
            cmd.Parameters.AddWithValue("@Namee", this.textBox10.Text);
            cmd.Parameters.AddWithValue("@MOPay", this.textBox9.Text);
            cmd.Parameters.AddWithValue("@Phno,", this.textBox4.Text);
            cmd.Parameters.AddWithValue("@Fees", this.textBox12.Text);
            cmd.Parameters.AddWithValue("@Floor", this.textBox11.Text);
            cmd.Parameters.AddWithValue("@Status", "OK");
            cmd.ExecuteNonQuery();
            conn.oleDbConnection1.Close();
            MessageBox.Show("Data updated");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.panel2.Visible = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.textBox5.Clear();
            this.textBox1.Clear();
            this.textBox3.Clear();
            this.textBox7.Clear();
            this.textBox8.Clear();
          

        }

        private void button5_Click_1(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click_2(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from Paymententry ", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView2.DataSource = dt;
            conn.oleDbConnection1.Close();
        }
    }
}
